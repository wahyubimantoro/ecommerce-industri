<?php

    header('Location:public/');
